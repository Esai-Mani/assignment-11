import React from 'react';

const Footer = () => {
  return (
    <footer style={{
      backgroundColor: "#1a1a1a",
      color: "#fff",
      padding: "30px 20px",
      textAlign: "center",
      width: "100%",
      boxShadow: "0 -2px 10px rgba(0,0,0,0.3)"
    }}>
      <h2 style={{ marginBottom: "15px" }}>MyStore</h2>

      <p style={{ marginBottom: "15px", color: "#ccc" }}>© 2025 MyStore. All rights reserved.</p>

      {/* Navigation Links */}
      <div style={{ marginBottom: "15px" }}>
        <a href="/" className="footer-link" style={{ margin: "0 10px", color: "#fff", textDecoration: "none" }}>Home</a>
        <a href="/about" className="footer-link" style={{ margin: "0 10px", color: "#fff", textDecoration: "none" }}>About</a>
        <a href="/products" className="footer-link" style={{ margin: "0 10px", color: "#fff", textDecoration: "none" }}>Products</a>
        <a href="/contact" className="footer-link" style={{ margin: "0 10px", color: "#fff", textDecoration: "none" }}>Contact</a>
      </div>

      {/* Social Links */}
      <div style={{ marginBottom: "15px" }}>
        <a href="https://facebook.com" className="footer-social" style={{ margin: "0 10px", color: "#fff", textDecoration: "none" }}>Facebook</a>
        <a href="https://instagram.com" className="footer-social" style={{ margin: "0 10px", color: "#fff", textDecoration: "none" }}>Instagram</a>
        <a href="https://twitter.com" className="footer-social" style={{ margin: "0 10px", color: "#fff", textDecoration: "none" }}>Twitter</a>
      </div>

      {/* Newsletter Subscription */}
      <div style={{ display: "flex", flexDirection: "row", justifyContent: "center", flexWrap: "wrap" }}>
        <input 
          type="email" 
          placeholder="Subscribe to newsletter" 
          style={{
            padding: "10px",
            borderRadius: "5px",
            border: "none",
            marginRight: "10px",
            marginBottom: "10px",
            width: "250px",
          }}
        />
        <button style={{
          padding: "10px 20px",
          border: "none",
          borderRadius: "5px",
          backgroundColor: "#ff6600",
          color: "#fff",
          cursor: "pointer",
          fontWeight: "500"
        }}>Subscribe</button>
      </div>

      {/* Inline CSS for hover and responsiveness */}
      <style>
        {`
          .footer-link:hover {
            color: #ff6600;
          }
          .footer-social:hover {
            color: #fff;
            text-decoration: underline;
          }

          @media (max-width: 600px) {
            input {
              width: 100%;
              margin-bottom: 10px;
            }
            button {
              width: 100%;
            }
          }
        `}
      </style>
    </footer>
  );
};

export default Footer;
