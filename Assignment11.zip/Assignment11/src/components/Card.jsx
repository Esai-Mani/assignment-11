import React from "react";

const Card = ({ title, image, onClick }) => {
  return (
    <div
      style={{
        display: "inline-block",
        margin: "10px",
        padding: "10px",
        border: "2px solid #333",
        borderRadius: "10px",
        textAlign: "center",
        cursor: "pointer",
        backgroundColor: "rgba(255,255,255,0.8)"
      }}
      onClick={onClick}
    >
      {image && <img src={image} alt={title} style={{ width: "100px" }} />}
      <h3>{title}</h3>
    </div>
  );
};

export default Card;
