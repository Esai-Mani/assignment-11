import React from "react";
import { Link } from "react-router-dom";

const Header = () => {
  return (
    <nav style={{ padding: "20px", background: "#ADD8E6", color: "purple" }}>
      <Link to="/" style={{ color: "#800000", marginRight: "15px" }}>Home</Link>
      <Link to="/letters" style={{ color: "#800000", marginRight: "15px" }}>Letters</Link>
      <Link to="/numbers" style={{ color: "#800000", marginRight: "15px" }}>Numbers</Link>
      <Link to="/colors" style={{ color: "#800000", marginRight: "15px" }}>Colors</Link>
      <Link to="/shapes" style={{ color: "#800000", marginRight: "15px" }}>Shapes</Link>
      <Link to="/quiz" style={{ color: "#800000", marginRight: "15px" }}>Quiz</Link>
      <Link to="/user" style={{ color: "#800000" }}>Users</Link>
    </nav>
  );
};
export default Header;
