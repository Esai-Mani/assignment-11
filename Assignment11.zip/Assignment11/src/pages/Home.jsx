import React from "react";
import { Link } from "react-router-dom";

const Home = () => {
  const sections = [
    { name: "Letters", path: "/letters", color: "#FFB6C1" },
    { name: "Numbers", path: "/numbers", color: "#87CEFA" },
    { name: "Colors", path: "/colors", color: "#FFD700" },
    { name: "Shapes", path: "/shapes", color: "#90EE90" },
  ];

  return (
    <div
  style={{
    position: "relative",
    minHeight: "100vh",
    backgroundImage: `url("https://i.pinimg.com/736x/e6/b6/ca/e6b6ca34594b195e57c656177db2d978.jpg")`,
    backgroundSize: "cover",
    backgroundPosition: "center",
    color: "#333",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    padding: "120px 20px",
  }}
>
  <div
    style={{
      position: "absolute",
      top: 0,
      left: 0,
      width: "100%",
      height: "100%",
      backgroundColor: "rgba(0,0,0,0.3)", 
      zIndex: 1,
    }}
  ></div>

 
  <div style={{ position: "relative", zIndex: 2, textAlign: "center", color: "white", textShadow: "2px 2px 4px black" }}>
    <h1 style={{ fontSize: "3rem", marginBottom: "10px" }}>
      Welcome to Kids Learning Hub!
    </h1>
    <p style={{ fontSize: "1.2rem", marginBottom: "70px", maxWidth: "700px", margin: "0 auto" }}>
      Click on a section below to start learning letters, numbers, colors, and shapes!
    </p>

 
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))",
        gap: "20px",
        width: "100%",
        maxWidth: "800px",
        marginTop: "20px",
      }}
      
    >
      {sections.map((section) => (
        <Link
          to={section.path}
          key={section.name}
          style={{
            background: section.color,
            color: "#fff",
            textDecoration: "none",
            padding: "30px 20px",
            borderRadius: "15px",
            textAlign: "center",
            fontSize: "1.5rem",
            fontWeight: "bold",
            boxShadow: "2px 2px 10px rgba(0,0,0,0.3)",
            transition: "transform 0.3s, box-shadow 0.3s",
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.transform = "scale(1.1)";
            e.currentTarget.style.boxShadow = "4px 4px 15px rgba(0,0,0,0.4)";
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.transform = "scale(1)";
            e.currentTarget.style.boxShadow = "2px 2px 10px rgba(0,0,0,0.3)";
          }}
          
        >
          {section.name}
        </Link>
        
      ))}
    </div>
  </div>
</div>

  );
};

export default Home;
