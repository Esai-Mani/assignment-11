import React from "react";

const Numbers = () => {
  const numbers = [
    { num: 1, text: "One", img: "https://i.pinimg.com/736x/7e/29/f6/7e29f6682ad46bb5a3106c9ed1ec4806.jpg" },
    { num: 2, text: "Two", img: "https://i.pinimg.com/736x/96/e6/85/96e6853530aee5991d93b34bc583b72c.jpg" },
    { num: 3, text: "Three", img: "https://i.pinimg.com/736x/44/c4/4d/44c44d8a67b7511e9b43b9b42a49c958.jpg" },
    { num: 4, text: "Four", img: "https://i.pinimg.com/736x/d2/23/60/d22360dc97cf2cbdf748a80e5c4db8ef.jpg" },
    { num: 5, text: "Five", img: "https://i.pinimg.com/1200x/1a/fc/c8/1afcc8d11f0cbc3a52887e0255f0e72c.jpg" },
    { num: 6, text: "Six", img: "https://i.pinimg.com/736x/06/22/45/0622457a96d4af72a586e5a42b2ad826.jpg" },
    { num: 7, text: "Seven", img: "https://i.pinimg.com/1200x/87/90/30/87903010d6a0f687f6758b37c16bbed9.jpg" },
    { num: 8, text: "Eight", img: "https://i.pinimg.com/736x/e1/2f/b0/e12fb0e2fe2021b566c4d6061932ceb8.jpg" },
    { num: 9, text: "Nine", img: "https://i.pinimg.com/1200x/37/b0/3b/37b03b43e3dc0c3b98c647b946c336aa.jpg" },
    { num: 10, text: "Ten", img: "https://i.pinimg.com/736x/5d/06/b3/5d06b3b84220cb260e24105a7ec78290.jpg" },
  ];

  return (
    <div
      style={{
        padding: "20px",
        textAlign: "center",
        minHeight: "100vh",
        backgroundImage: "url('https://thumbs.dreamstime.com/b/print-182411869.jpg')",
        backgroundSize: "cover",
        backgroundRepeat: "no-repeat",
        backgroundPosition: "center",
      }}
    >
      <h1 style={{ fontSize: "32px", marginBottom: "10px", color: "darkblue" }}>
        Numbers
      </h1>
      <p style={{ fontSize: "18px", color: "purple", marginBottom: "20px" }}>
        Learn numbers with pictures and names!
      </p>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(5, 1fr)", // 5 items per row
          gap: "20px",
          maxWidth: "1200px",
          margin: "0 auto",
        }}
      >
        {numbers.map((item, index) => (
          <div
            key={index}
            style={{
              borderRadius: "12px",
              padding: "15px",
              textAlign: "center",
              background: `hsl(${index * 36}, 70%, 90%)`, // different pastel color per box
              boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
              transition: "transform 0.3s, box-shadow 0.3s",
              cursor: "pointer",
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = "scale(1.05)";
              e.currentTarget.style.boxShadow = "0 4px 12px rgba(0,0,0,0.2)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = "scale(1)";
              e.currentTarget.style.boxShadow = "0 2px 8px rgba(0,0,0,0.1)";
            }}
          >
            <h2 style={{ fontSize: "22px", color: "#2c5e1a" }}>{item.num}</h2>
            <img
              src={item.img}
              alt={item.text}
              style={{
                width: "100px",
                height: "100px",
                objectFit: "cover",
                borderRadius: "8px",
              }}
            />
            <p style={{ marginTop: "10px", fontSize: "16px" }}>{item.text}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Numbers;
