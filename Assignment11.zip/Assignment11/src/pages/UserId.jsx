import React from "react";
import { useParams, Link } from "react-router-dom";

const UserId = () => {
  const { id } = useParams();
  const users = [
    { id: 1, name: "Esakkiammal Chandran" },
    { id: 2, name: "Manikandan R" },
    { id: 3, name: "Suba Mithran" },
    { id: 4, name: "Preetitha Smiley" },
    { id: 5, name: "Elan Theeran" },
    { id: 6, name: "Isha Magathi" },
    { id: 7, name: "Prejan Arya" },
  ];

  const user = users.find((u) => u.id === parseInt(id));

  return (
    <div
      style={{
        padding: "20px",
        textAlign: "center",
        minHeight: "100vh",
        backgroundImage:
          "url('https://img.freepik.com/free-photo/high-angle-view-laptop-stationeries-blue-background_23-2147880456.jpg')",
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      <h1 style={{ marginBottom: "20px", color: "green" }}>User Details</h1>

      {user ? (
        <div
          style={{
            background: "rgba(255,255,255,0.9)",
            padding: "20px",
            borderRadius: "12px",
            display: "inline-block",
            boxShadow: "0 2px 8px rgba(0,0,0,0.2)",
          }}
        >
          <p style={{ fontSize: "18px" }}>
            <strong>User ID:</strong> {user.id} <br />
            <strong
              style={{
                fontSize: "26px",
                fontWeight: "700",
                letterSpacing: "1px",
                background: "linear-gradient(90deg, #ff6ec4, #7873f5, #42e695)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                animation: "gradient 3s infinite linear",
                display: "inline-block",
                backgroundSize: "200% auto",
              }}
            >
              {user.name}
            </strong>
          </p>
        </div>
      ) : (
        <p style={{ color: "yellow", fontWeight: "bold" }}>⚠ User not found</p>
      )}

      <br />
      <Link
        to="/user"
        style={{
          marginTop: "20px",
          display: "inline-block",
          padding: "10px 15px",
          background: "#007bff",
          color: "#fff",
          borderRadius: "8px",
          textDecoration: "none",
          fontWeight: "500",
        }}
      >
        ⬅ Back to User List
      </Link>

    
      <style>
        {`
          @keyframes gradient {
            0% { background-position: 0% }
            50% { background-position: 100% }
            100% { background-position: 0% }
          }
        `}
      </style>
    </div>
  );
};

export default UserId;
