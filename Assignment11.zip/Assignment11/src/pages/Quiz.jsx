import React, { useState } from "react";

const Quiz = () => {
  const questions = [
    {
      text: "Which one is a Circle?",
      options: ["⬛ Square", "⬤ Circle", "🔺 Triangle", "⬢ Hexagon"],
      answer: 1,
    },
    {
      text: "How many sides does a Triangle have?",
      options: ["2", "3", "4", "5"],
      answer: 1,
    },
    {
      text: "Which number comes after 7?",
      options: ["5", "6", "8", "9"],
      answer: 2,
    },
    {
      text: "Which is a primary color?",
      options: ["Green", "Red", "Black", "Pink"],
      answer: 1,
    },
    {
      text: "Which shape has 4 equal sides?",
      options: ["Circle", "Rectangle", "Square", "Triangle"],
      answer: 2,
    },
  ];

  const [current, setCurrent] = useState(0);
  const [selected, setSelected] = useState(null);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);

  const handleSelect = (index) => {
    setSelected(index);
  };

  const handleNext = () => {
    if (selected === questions[current].answer) {
      setScore(score + 1);
    }

    setSelected(null);

    if (current + 1 < questions.length) {
      setCurrent(current + 1);
    } else {
      setShowResult(true);
    }
  };

  const handleRestart = () => {
    setCurrent(0);
    setSelected(null);
    setScore(0);
    setShowResult(false);
  };

  return (
    <div style={{ padding: "20px", textAlign: "center" }}>
      <h1 style={{ fontSize: "28px", color: "#2c5e1a", marginBottom: "15px" }}>
        Quiz Page
      </h1>

      {!showResult ? (
        <div
          style={{
            maxWidth: "500px",
            margin: "0 auto",
            background: "#f0f8ff",
            padding: "20px",
            borderRadius: "12px",
            boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
          }}
        >
          <h2 style={{ marginBottom: "20px" }}>
            Q{current + 1}. {questions[current].text}
          </h2>

          {questions[current].options.map((option, index) => (
            <button
              key={index}
              onClick={() => handleSelect(index)}
              style={{
                display: "block",
                width: "100%",
                padding: "10px",
                margin: "10px 0",
                borderRadius: "8px",
                border: "2px solid #ccc",
                background: selected === index ? "#007bff" : "#fff",
                color: selected === index ? "#fff" : "#000",
                cursor: "pointer",
                fontSize: "16px",
                fontWeight: "500",
                transition: "0.3s",
              }}
            >
              {option}
            </button>
          ))}

          <button
            onClick={handleNext}
            disabled={selected === null}
            style={{
              marginTop: "15px",
              padding: "10px 20px",
              borderRadius: "8px",
              border: "none",
              background: selected !== null ? "#28a745" : "#aaa",
              color: "#fff",
              cursor: selected !== null ? "pointer" : "not-allowed",
              fontSize: "16px",
              fontWeight: "600",
            }}
          >
            {current + 1 === questions.length ? "Finish" : "Next"}
          </button>
        </div>
      ) : (
        <div
          style={{
            maxWidth: "400px",
            margin: "0 auto",
            padding: "20px",
            background: "#e6ffe6",
            borderRadius: "12px",
            boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
          }}
        >
          <h2>🎉 Quiz Completed!</h2>
          <p style={{ fontSize: "18px", fontWeight: "600" }}>
            Your Score: {score} / {questions.length}
          </p>
          <button
            onClick={handleRestart}
            style={{
              marginTop: "15px",
              padding: "10px 20px",
              borderRadius: "8px",
              border: "none",
              background: "#007bff",
              color: "#fff",
              cursor: "pointer",
              fontSize: "16px",
              fontWeight: "600",
            }}
          >
            Restart Quiz
          </button>
        </div>
      )}
    </div>
  );
};

export default Quiz;
