import React from "react";
import { Link } from "react-router-dom";

const User = () => {
  const users = [
    { id: 1, name: "Esai", img: "https://t4.ftcdn.net/jpg/02/44/43/83/360_F_244438372_tqgUKRtdGk61Z6YuK79ufAhYpgXcB7xv.jpg" },
    { id: 2, name: "Mani", img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQwgup25-AQJL7UBrhQzgU37Cj6Uqn-RrTIYgYWpIgw1DppK4g03BNSXzaPCNJbrcNHR-Q&usqp=CAU" },
    { id: 3, name: "Mithran", img: "https://www.freeiconspng.com/uploads/blue-user-icon-32.jpg" },
    { id: 4, name: "Smiley", img: "https://t4.ftcdn.net/jpg/02/44/43/83/360_F_244438372_tqgUKRtdGk61Z6YuK79ufAhYpgXcB7xv.jpg" },
    { id: 5, name: "Theeran", img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ4Y1gfFOnYmK1eAHFrXdkJT6WLCzw6lQLj_37RtB_JsILz0dlOegv06kCtgvPonHutlOU&usqp=CAU" },
    { id: 6, name: "Isha", img: "https://t4.ftcdn.net/jpg/02/44/43/83/360_F_244438372_tqgUKRtdGk61Z6YuK79ufAhYpgXcB7xv.jpg" },
    { id: 7, name: "prejan", img: "https://t4.ftcdn.net/jpg/02/44/43/69/360_F_244436923_vkMe10KKKiw5bjhZeRDT05moxWcPpdmb.jpg" },
  ];

  return (
    <div style={{ padding: "200px", textAlign: "center", backgroundColor:"yellowgreen" }}>
      <h1 style={{ marginBottom: "20px", color:"purple"}}>User List</h1>
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          flexWrap: "wrap",
          gap: "20px",
        }}
      >
        {users.map((user) => (
          <Link
            key={user.id}
            to={`/user/${user.id}`}
            style={{
              textDecoration: "none",
              color: "#000",
              width: "150px",
              borderRadius: "12px",
              boxShadow: "0 2px 10px rgba(0,0,0,0.1)",
              overflow: "hidden",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              transition: "transform 0.2s, box-shadow 0.2s",
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = "scale(1.05)";
              e.currentTarget.style.boxShadow = "0 4px 20px rgba(0,0,0,0.2)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = "scale(1)";
              e.currentTarget.style.boxShadow = "0 2px 10px rgba(0,0,0,0.1)";
            }}
          >
            <img
              src={user.img}
              alt={user.name}
              style={{ width: "100%", height: "150px", objectFit: "cover" }}
            />
            <p style={{ padding: "10px", fontWeight: "bold", color:"purple"}}>{user.name}</p>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default User;
