import React, { useState } from "react";

const data = [
  { l: "A", examples: [{ word: "Apple", img: "https://thumbs.dreamstime.com/b/red-apple-isolated-clipping-path-19130134.jpg" }, { word: "Ant", img: "https://t4.ftcdn.net/jpg/00/90/98/53/360_F_90985363_MVFx1czghxJechCp7HM85bKJv1vUQN2c.jpg" }] },
  { l: "B", examples: [{ word: "Ball", img: "https://media.istockphoto.com/id/459985083/photo/colorful-ball.jpg?s=612x612&w=0&k=20&c=Lojn77HvymQHAMN63ran7jot8JtDnzu8XASUvU1voDE=" }, { word: "Boat", img: "https://thumbs.dreamstime.com/b/wooden-boat-small-fishing-water-moored-distance-shore-36216618.jpg" }] },
  { l: "C", examples: [{ word: "Cat", img: "https://www.alleycat.org/wp-content/uploads/2019/03/FELV-cat.jpg" }, { word: "Car", img: "https://images.drivespark.com/webp/fit-in/640x480/car-image/car/37923980-mercedes_benz_s_class.jpg" }] },
  { l: "D", examples: [{ word: "Dog", img: "https://www.shutterstock.com/image-photo/beautiful-golden-retriever-cute-puppy-600nw-2526542701.jpg" }, { word: "Duck", img: "https://nutrenaworld.com/wp-content/uploads/2024/01/poultry_blog_ducks-special-dietary-needs_820x525.jpg" }] },
  { l: "E", examples: [{ word: "Egg", img: "https://cdn.britannica.com/94/151894-050-F72A5317/Brown-eggs.jpg" }, { word: "Elephant", img: "https://th-i.thgim.com/public/incoming/pq3ac3/article69939889.ece/alternates/FREE_1200/IMG_promo_2_1_18EP7LFJ.jpg" }] },
  { l: "F", examples: [{ word: "Fish", img: "https://us.123rf.com/450wm/dmz/dmz1104/dmz110400252/9288338-cute-little-fish-in-an-aquarium.jpg?ver=6" }, { word: "Frog", img: "https://cdn.hswstatic.com/gif/frog-1.jpg" }] },
  { l: "G", examples: [{ word: "Grapes", img: "https://m.media-amazon.com/images/I/51qW4jcUVJL._UF1000,1000_QL80_.jpg" }, { word: "Goat", img: "https://www.woldswildlife.co.uk/images/uploads/animal_introduction_images/boer_vpse.jpeg" }] },
  { l: "H", examples: [{ word: "Hat", img: "https://assetscdn1.paytm.com/images/catalog/product/A/AC/ACCHIGH-QUALITYRIDH1001150128853C5/1570184463225_0..jpg?imwidth=540&impolicy=hq" }, { word: "Horse", img: "https://www.shutterstock.com/image-photo/beautiful-horse-running-autumn-600nw-2430263853.jpg" }] },
  { l: "I", examples: [{ word: "Ice cream", img: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/31/Ice_Cream_dessert_02.jpg/960px-Ice_Cream_dessert_02.jpg" }, { word: "Igloo", img: "https://www.shutterstock.com/image-photo/igloo-holiday-eskimo-dwelling-made-260nw-2591990799.jpg" }] },
  { l: "J", examples: [{ word: "Juice", img: "https://www.rawpressery.com/cdn/shop/files/mixedfruitdrink.jpg?v=1685692121&width=416" }, { word: "Jelly fish", img: "https://static.scientificamerican.com/sciam/cache/file/B7E980C5-B182-4A2E-80369F2AC535EB35_source.jpg?crop=16%3A9%2Csmart&w=1920" }] },
  { l: "K", examples: [{ word: "Kite", img: "https://www.earthtoys.net/cdn/shop/articles/kite_1417x.jpg?v=1457701558" }, { word: "King", img: "https://static.vecteezy.com/system/resources/thumbnails/049/897/647/small_2x/a-whimsical-drawing-of-a-king-in-a-cartoon-style-great-for-playful-and-imaginative-projects-vector.jpg" }] },
  { l: "L", examples: [{ word: "Lion", img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQrFWThXQto_u0ECqT4XaYVssxSfSj8HMQWJw&s" }, { word: "Leaf", img: "https://t3.ftcdn.net/jpg/06/11/24/66/360_F_611246666_UuaYs1qQuJllipq03mHE8o3Szd8D8uCV.jpg" }] },
  { l: "M", examples: [{ word: "Mango", img: "https://www.metropolisindia.com/upgrade/blog/upload/25/05/benefits-of-mangoes1747828357.webp" }, { word: "Moon", img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRsthbQ342zP_UQrYtZAik9w_ci4tRxSEQrCg&s" }] },
  { l: "N", examples: [{ word: "Nest", img: "https://onlymat.com/cdn/shop/products/IMG_014700033.JPG?v=1588514068&width=1445" }, { word: "Nose", img: "https://thumbs.dreamstime.com/b/close-up-human-nose-image-features-light-beige-hue-soft-textures-lighting-focused-highlights-subtle-details-skin-s-381040181.jpg" }] },
  { l: "O", examples: [{ word: "Orange", img: "https://fruitique.in/cdn/shop/products/Mandarin-orange_1024x1024.jpg?v=1625786754" }, { word: "Owl", img: "https://images.pexels.com/photos/86596/owl-bird-eyes-eagle-owl-86596.jpeg?cs=srgb&dl=pexels-pixabay-86596.jpg&fm=jpg" }] },
  { l: "Q", examples: [{ word: "Queen", img: "https://png.pngtree.com/png-clipart/20250104/original/pngtree-beautiful-queen-clipart-png-image_19911476.png" }, { word: "Quilt", img: "https://memorystitch.com/cdn/shop/products/product-photo_onesie-quilts.jpg?v=1681308796" }] },
  { l: "R", examples: [{ word: "Rabbit", img: "https://i.pinimg.com/736x/2d/15/74/2d157475da3f359c2bfcd10875aaa872.jpg" }, { word: "Rainbow", img: "https://static.toiimg.com/thumb/msid-121850615,width-1280,height-720,resizemode-4/121850615.jpg" }] },
  { l: "S", examples: [{ word: "Sun", img: "https://www.sciencing.com/sciencing/five-characteristics-sun-8720219/7ebf43ead3f44fffafc00fd2efc0f7f5.jpg" }, { word: "Star", img: "https://images.rawpixel.com/image_png_800/cHJpdmF0ZS9sci9pbWFnZXMvd2Vic2l0ZS8yMDIyLTEwL3JtNDY3YmF0Y2gyLXN0YXItMDAxXzEucG5n.png" }] },
  { l: "T", examples: [{ word: "Tiger", img: "https://live.staticflickr.com/65535/52064188709_649c474cc5_z.jpg" }, { word: "Train", img: "https://m.media-amazon.com/images/I/61DvDneyavL._UF1000,1000_QL80_.jpg" }] },
  { l: "U", examples: [{ word: "Umbrella", img: "https://m.media-amazon.com/images/I/71LaquPBn7S._UY350_.jpg" }, { word: "Unicorn", img: "https://www.shutterstock.com/image-vector/cute-cartoon-rainbow-unicorn-vector-600nw-2487769365.jpg" }] },
  { l: "V", examples: [{ word: "Van", img: "https://5.imimg.com/data5/SELLER/Default/2021/7/HM/QD/KB/65549/tata-magic-school-van-500x500.png" }, { word: "Violin", img: "https://www.bajaao.com/cdn/shop/files/VAU-FIDDLER44_f9185888-1e3c-48a9-b192-d23d6ae92030.jpg?v=1732505204" }] },
  { l: "W", examples: [{ word: "Watch", img: "https://m.media-amazon.com/images/I/61ZjlBOp+rL._UF1000,1000_QL80_.jpg" }, { word: "Whale", img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRYvOeThOiy6yYubzJdq3Otnz0cj9Mh24Et2g&s" }] },
  { l: "X", examples: [{ word: "Xylophone", img: "https://baybee.co.in/cdn/shop/files/71W0Cu1jUBL.jpg?v=1744996752" }, { word: "X-ray", img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSpG0xwjiIHyvGSCIJDOCZ_VEzEntS0LHnhCQ&s" }] },
  { l: "Y", examples: [{ word: "Yoyo", img: "https://www.shutterstock.com/image-vector/yoyo-260nw-273937748.jpg" }, { word: "Yellow", img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR4rbwv17Vj73Ipf0TArp6kg0Ki36ryd4Uuag&s" }] },
  { l: "Z", examples: [{ word: "Zebra", img: "https://www.sciencing.com/sciencing/characteristics-zebra-8001369/153717005.jpg" }, { word: "Zip", img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRtCobcdMRGjuU9EjC4lOZae5ghFdks8B2J1Q&s" }] },
];

function ImgCard({ word, src }) {
  const [ok, setOk] = useState(true);
  const imgStyle = {
    width: "100%",
    height: 100,
    objectFit: "cover",
    borderRadius: 8,
    display: "block",
  };
  return (
    <div style={{
      width: 220,
      border: "1px solid #e6e6e6",
      borderRadius: 12,
      overflow: "hidden",
      background: "#fff",
      boxShadow: "0 2px 6px rgba(0,0,0,0.04)",
    }}>
      {ok ? (
        <img src={src} alt={word} style={imgStyle} onError={() => setOk(false)} />
      ) : (
        <div style={{ width: "100%", height: 100, display: "grid", placeItems: "center", background: "#f3f3f3" }}>
          No Image
        </div>
      )}
      <div style={{ padding: "8px 10px", fontWeight: 600, textAlign: "center" }}>{word}</div>
    </div>
  );
}

export default function Letters() {
  const container = {
    padding: 20,
    backgroundImage:
      "url('https://i.pinimg.com/736x/98/62/e7/9862e77d1c181bf907aff2030b5c810a.jpg')",
    backgroundSize: "cover",        
    backgroundRepeat: "no-repeat",  
    backgroundPosition: "center",   
    minHeight: "100vh",
    fontFamily: "'Segoe UI', Roboto, Arial, sans-serif",
    color: "olivedrab",
  };
  

  const header = {
   
    marginBottom: 18,
    
    textAlign:"center",
  };

  const cardsWrap = {
    display: "flex",
    flexWrap: "wrap",
    gap: 18,
    justifyContent: "center",
  };

  const letterCard = {
    width: 480,
    minHeight: 160,
    borderRadius: 14,
    padding: 14,
    boxSizing: "border-box",
    background: "teal",
    border: "1px solid #eee",
    display: "flex",
    gap: 12,
    alignItems: "center",
    justifyContent: "space-between",
    flexWrap: "wrap",
  };

  const letterBadge = {
    width: 110,
    height: 110,
    borderRadius: 12,
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    background: "linear-gradient(180deg,#fff 0%,#f0fff0 100%)",
    border: "1px solid #e6efe6",
    marginRight: 8,
  };

  const big = { fontSize: 48, fontWeight: 800, lineHeight: 1 };
  const small = { fontSize: 16, color: "#4b5563", marginTop: 6 };

  return (
    <div style={container}>
      <div style={header}>
        <div>
          <h1 style={{ margin: 0, fontSize: "28px",color:"blue",padding:"5px", textAlign:"center", padding:"5px"}}>A–Z Letters </h1>
          <div style={{ marginTop: 6, fontSize: 20, textAlign:"center", color:"blue" }}>An alphabet is a set of special symbols called letters, arranged in a particular order, that are used to write down a language.</div>
        </div>
      </div>

      <div style={cardsWrap}>
        {data.map(({ l, examples }) => (
          <div key={l} style={letterCard}>
            <div style={letterBadge}>
              <div style={big}>{l}</div>
              <div style={small}>{l.toLowerCase()}</div>
            </div>

            <div style={{ display: "flex", gap: 12, flexWrap: "wrap", justifyContent: "flex-end", flex: 1 }}>
              {examples.map((ex, i) => (
                <ImgCard key={i} word={ex.word} src={ex.img} />
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
