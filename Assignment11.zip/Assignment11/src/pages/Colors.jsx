import React from "react";

const Colors = () => {
  const colors = [
    { name: "Red", hex: "#FF0000" },
    { name: "Blue", hex: "#0000FF" },
    { name: "Green", hex: "#008000" },
    { name: "Yellow", hex: "#FFD700" },
    { name: "Orange", hex: "#FFA500" },
    { name: "Purple", hex: "#800080" },
    { name: "Pink", hex: "#FFC0CB" },
    { name: "Brown", hex: "#8B4513" },
    { name: "Black", hex: "#000000" },
    { name: "White", hex: "#FFFFFF" },
  ];

  return (
    <div style={{ padding: "20px", textAlign: "center" }}>
      <h1 style={{ fontSize: "28px", marginBottom: "10px", color: " #0000ff" }}>
        Colors
      </h1>
      <p style={{ fontSize: "16px", color: " #0000ff", marginBottom: "20px" }}>
        Learn colors with their names!
      </p>

     
      <div
  style={{
    display: "grid",
    gridTemplateColumns: "repeat(5, 1fr)",
    gap: "20px",
    width: "100%",             
    margin: "0 auto",
    padding: "20px",
    backgroundImage:
      "url('https://img.freepik.com/free-photo/gray-painted-background_53876-94041.jpg?semt=ais_hybrid&w=740&q=80')",
    backgroundSize: "cover",
    backgroundPosition: "center",
    borderRadius: "12px",
  }}
>

        {colors.map((color, index) => (
          <div
            key={index}
            style={{
              borderRadius: "12px",
              padding: "15px",
              textAlign: "center",         
              background: "#ffe6e6",
              boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
            }}
          >
          
            <div
              style={{
                width: "100px",
                height: "100px",
                background: color.hex,
                margin: "0 auto 10px",
                borderRadius: "8px",
                border: "2px solid #ccc",
              }}
            ></div>

            <p style={{ fontSize: "16px", fontWeight: "500" }}>{color.name}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Colors;
