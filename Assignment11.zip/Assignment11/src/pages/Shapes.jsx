import React from "react";

const Shapes = () => {
  const shapes = [
    { name: "Circle", style: { borderRadius: "50%" } },
    { name: "Square", style: {} },
    { name: "Rectangle", style: { width: "120px", height: "80px" } },
    {
      name: "Triangle",
      style: {
        width: "0",
        height: "0",
        borderLeft: "50px solid transparent",
        borderRight: "50px solid transparent",
        borderBottom: "100px solid", 
        background: "none",
      },
      isTriangle: true,
    },
    { name: "Oval", style: { borderRadius: "50%", width: "120px", height: "80px" } },
    { name: "Diamond", style: { transform: "rotate(45deg)", width: "100px", height: "100px" } },
    {
      name: "Pentagon",
      style: {
        clipPath: "polygon(50% 0%, 100% 38%, 82% 100%, 18% 100%, 0% 38%)",
      },
    },
    {
      name: "Hexagon",
      style: {
        clipPath:
          "polygon(25% 0%, 75% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%)",
      },
    },
  ];

  const colors = [
    "#FF5733", 
    "#33B5FF", 
    "#28A745", 
    "#FFC300", 
    "#9B59B6", 
    "#E91E63", 
    "#17A2B8", 
    "#FF9800", 
  ];

  return (
    <div style={{ padding: "20px", textAlign: "center" }}>
      <h1 style={{ fontSize: "28px", marginBottom: "10px", color: "#2c5e1a" }}>
        Shapes
      </h1>
      <p style={{ fontSize: "16px", color: "#555", marginBottom: "20px" }}>
        Learn shapes with their names!
      </p>

      
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(4, 1fr)",
          gap: "20px",
          maxWidth: "1000px",
          margin: "0 auto",
        }}
      >
        {shapes.map((shape, index) => (
          <div
            key={index}
            style={{
              borderRadius: "12px",
              padding: "15px",
              textAlign: "center",
              background: "#f0f8ff",
              boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
              backgroundColor:"#ADD8E6",
            }}
          >
            {shape.isTriangle ? (
              <div
                style={{
                  ...shape.style,
                  borderBottom: `100px solid ${colors[index]}`, 
                  margin: "0 auto 10px",
                }}
              ></div>
            ) : (
              <div
                style={{
                  width: shape.style.width || "100px",
                  height: shape.style.height || "100px",
                  background: colors[index], // 
                  margin: "0 auto 10px",
                  ...shape.style,
                }}
              ></div>
            )}

            <p style={{ fontSize: "16px", fontWeight: "500" }}>{shape.name}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Shapes;
