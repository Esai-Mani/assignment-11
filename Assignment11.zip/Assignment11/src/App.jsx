import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Letters from "./pages/Letters";
import Numbers from "./pages/Numbers";
import Colors from "./pages/Colors";
import Shapes from "./pages/Shapes";
import Quiz from "./pages/Quiz";
import User from "./pages/User";
import UserId from "./pages/UserId";
import Header from "./components/Header";
import Footer from "./components/Footer"; // Import Footer

function App() {
  return (
    <Router>
      <div style={{
        display: "flex",
        flexDirection: "column",
        minHeight: "100vh"
      }}>
        <Header />
        <main style={{ flex: 1, padding: "20px" }}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/letters" element={<Letters />} />
            <Route path="/numbers" element={<Numbers />} />
            <Route path="/colors" element={<Colors />} />
            <Route path="/shapes" element={<Shapes />} />
            <Route path="/quiz" element={<Quiz />} />
            <Route path="/user" element={<User />} />
            <Route path="/user/:id" element={<UserId />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
